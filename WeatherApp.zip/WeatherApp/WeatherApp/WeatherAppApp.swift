//
//  WeatherAppApp.swift
//  WeatherApp
//
//  Created by Stephanie Diep on 2021-11-30.
//

import SwiftUI

@main
struct WeatherAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
