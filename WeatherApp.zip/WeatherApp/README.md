<!-- AUTO-GENERATED-CONTENT:START (STARTER) -->
<h1 align="center">
  🌤 WeatherApp tutorial
</h1>
Source code for the WeatherApp built in the <a href="https://youtu.be/X2W9MPjrIbk">YouTube tutorial</a>

Access the three-part written content here:
- [Weather app Part 1](https://designcode.io/swiftui-advanced-handbook-weather-app-1)
- [Weather app Part 2](https://designcode.io/swiftui-advanced-handbook-weather-app-2)
- [Weather app Part 3](https://designcode.io/swiftui-advanced-handbook-weather-app-3)  
  
<!-- AUTO-GENERATED-CONTENT:END -->
