/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The application delegate that sets up and starts the virtual machine.
*/

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end
